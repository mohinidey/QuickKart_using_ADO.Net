﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;



namespace QuickKartDataAccessLayer
{
    public class DataAccessLayer
    {
        //01. Demo - Connecting to database
        SqlConnection conQuickKart;
        SqlCommand cmdQuickKart;
        SqlDataAdapter daQuickKart;
        public DataAccessLayer()
        {
            conQuickKart = new SqlConnection(ConfigurationManager.ConnectionStrings["conQuickKart"].ToString());
        }
        public bool TestConnection()
        {
            //Create a SQL connection
            //SqlConnection conQuickKart = new SqlConnection();
            //conQuickKart.ConnectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=QuickKart_ADO; Integrated Security=SSPI";

            //SqlConnection conQuickKart = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=QuickKart_ADO; Integrated Security=SSPI/TRUE");
            //SqlConnection conQuickKart = new SqlConnection(ConfigurationManager.ConnectionStrings["conQuickKart"].ToString());
            bool status = false;
            try
            {
                //Open connection
                //To check systems data if any connection is open else it will give System.InvalidOperationException
                if (conQuickKart.State == ConnectionState.Closed)
                {
                    conQuickKart.Open(); //Open connection         
                    status = true;
                }
            }
            catch
            {
                status = false;
            }
            finally
            {
                //Close connection
                conQuickKart.Close();
            }
            return status;
        }

        //02. Demo - working with ExecuteScalar() 
        //public bool ValidateUser(string emailId, string password)
        public int ValidateUser(string emailId, string password)
        {
            int returnValue;
            //cmdQuickKart = new SqlCommand("SELECT COUNT(*) FROM Users where EmailId='" +
            //              emailId + "' AND UserPassword='" + password + "'", conQuickKart);

            //cmdQuickKart = new SqlCommand("SELECT COUNT(*) FROM Users where EmailId=@EmailId AND UserPassword = @Password", conQuickKart);
            cmdQuickKart = new SqlCommand(@"SELECT [dbo].ufn_ValidateUserCredentials(@EmailId,@Password)", conQuickKart);
            cmdQuickKart.Parameters.AddWithValue("@EmailId", emailId);
            cmdQuickKart.Parameters.AddWithValue("@Password", password);
            try
            {
                conQuickKart.Open();
                //returnValue = Convert.ToBoolean(cmdQuickKart.ExecuteScalar());
                returnValue = Convert.ToInt32(cmdQuickKart.ExecuteScalar());
            }
            catch (SqlException ex)
            {
                //returnValue = false;
                returnValue = -1;
            }
            finally
            {
                conQuickKart.Close();
            }
            return returnValue;
        }

        // 03. Working with ExecuteReader() 
        public SqlDataReader FetchCategories()
        {
            SqlDataReader drFetchCategories = null;
            try
            {
                //cmdQuickKart = new SqlCommand("SELECT CategoryId, CategoryName FROM Categories", conQuickKart);
                cmdQuickKart = new SqlCommand(@"SELECT * FROM ufn_GetCategories()", conQuickKart);
                conQuickKart.Open();
                //drFetchCategories = cmdQuickKart.ExecuteReader();
                drFetchCategories = cmdQuickKart.ExecuteReader(CommandBehavior.CloseConnection);
            }
            catch (SqlException ex)
            {
                drFetchCategories = null;
            }
            finally
            {
                //conQuickKart.Close();
            }
            return drFetchCategories;
        }
        // 04. Working with SQL query to add data
        //public int AddCategory(string categoryName)
        //{
        //    int rowsAffected = -1;
        //    cmdQuickKart = new SqlCommand("INSERT INTO Categories VALUES (@categoryName)", conQuickKart);
        //    cmdQuickKart.Parameters.AddWithValue("@categoryName", categoryName);
        //    try
        //    {
        //        conQuickKart.Open();
        //        rowsAffected = cmdQuickKart.ExecuteNonQuery();//ExecuteNonQuery() will resturn -1 by default else it returns no of affected rows
        //    }
        //    catch (SqlException ex)
        //    {
        //        rowsAffected = -1;
        //    }
        //    finally
        //    {
        //        conQuickKart.Close();
        //    }

        //    return rowsAffected;
        //}

        // 04. Working with Stored Procedures
        public int AddCategory(string categoryName, out int categoryId)
        {
            int returnVal = -1;
            cmdQuickKart = new SqlCommand("usp_AddCategory", conQuickKart);
            cmdQuickKart.CommandType = CommandType.StoredProcedure;

            cmdQuickKart.Parameters.AddWithValue("@CategoryName", categoryName);

            // Adding an output parameter to SqlCommand 
            SqlParameter prmCategoryId = new SqlParameter("@CategoryId", SqlDbType.TinyInt);
            prmCategoryId.Direction = ParameterDirection.Output;
            cmdQuickKart.Parameters.Add(prmCategoryId);
            // Adding an return parameter to SqlCommand object
            SqlParameter prmReturn = new SqlParameter();
            prmReturn.Direction = ParameterDirection.ReturnValue;
            cmdQuickKart.Parameters.Add(prmReturn);
            try
            {
                conQuickKart.Open();
                cmdQuickKart.ExecuteNonQuery();
                categoryId = Convert.ToInt32(prmCategoryId.Value);
                returnVal = Convert.ToInt32(prmReturn.Value);
            }
            catch (SqlException ex)
            {
                returnVal = -1;
                categoryId = -1;
                Console.WriteLine(ex);
            }
            finally
            {
                conQuickKart.Close();
            }
            return returnVal;
        }
        // 05. Demo: Working with DataAdapter - Fill
        public DataTable GetProducts(byte categoryId)
        {
            DataTable dtProducts = new DataTable();
            try
            {
                cmdQuickKart = new SqlCommand(@"SELECT * FROM ufn_GetProductDetails(@CategoryId)", conQuickKart);
                cmdQuickKart.Parameters.AddWithValue("@CategoryId", categoryId);
                daQuickKart = new SqlDataAdapter(cmdQuickKart);
                daQuickKart.Fill(dtProducts);
            }
            catch (SqlException ex)
            {
                dtProducts = null;
            }
            return dtProducts;
        }
        public DataTable FetchCategorieswithDataAdapter()
        {
            DataTable cat = new DataTable();
            try
            {
                cmdQuickKart = new SqlCommand(@"SELECT * FROM ufn_GetCategories()", conQuickKart);
                daQuickKart = new SqlDataAdapter(cmdQuickKart);
                daQuickKart.Fill(cat);
            }
            catch (Exception)
            {

                cat = null; 
            }
            return cat;
        }
        // 06. Working with Insert Command
        // 07. Working with Update Command
        public DataTable SaveChanges(DataTable dtCategories)
        {
            try
            {
                // Create the Insert command for the DataAdapter
                SqlCommand cmdInsertCategory = new SqlCommand();
                cmdInsertCategory.Connection = conQuickKart;
                cmdInsertCategory.CommandText = "INSERT INTO Categories VALUES(@CategoryName)";
                // Create the CategoryName parameter for the insert command
                SqlParameter prmCategoryName = new SqlParameter();
                prmCategoryName.ParameterName = "@CategoryName";
                prmCategoryName.SourceColumn = "CategoryName";
                // Add the parameter to the insert command created
                cmdInsertCategory.Parameters.Add(prmCategoryName);
                // Assign the Insert Command to the InsertCommand of the DataAdapter
                daQuickKart.InsertCommand = cmdInsertCategory;


                // Create the Update command for the DataAdapter
                SqlCommand cmdUpdateCategory = new SqlCommand();
                cmdUpdateCategory.Connection = conQuickKart;
                cmdUpdateCategory.CommandText = "UPDATE Categories SET CategoryName=@CategoryName WHERE CategoryId=@CategoryId";
                // Create the CategoryId parameter for the update command
                SqlParameter prmCategoryId = new SqlParameter();
                prmCategoryId.ParameterName = "@CategoryId";
                prmCategoryId.SourceColumn = "CategoryId";
                // Create the CategoryName parameter for the update command
                prmCategoryName = new SqlParameter();
                prmCategoryName.ParameterName = "@CategoryName";
                prmCategoryName.SourceColumn = "CategoryName";
                // Add the parameters to the update command created
                cmdUpdateCategory.Parameters.Add(prmCategoryId);
                cmdUpdateCategory.Parameters.Add(prmCategoryName);
                // Assign the Update Command to the UpdateCommand of the DataAdapter
                daQuickKart.UpdateCommand = cmdUpdateCategory;


                // Create the delete command for the DataAdapter
                SqlCommand cmdDeleteCategory = new SqlCommand();
                cmdDeleteCategory.Connection = conQuickKart;
                cmdDeleteCategory.CommandText = "DELETE FROM Categories WHERE CategoryId=@CategoryId";
                // Create the CategoryId parameter for the delete command
                prmCategoryId = new SqlParameter();
                prmCategoryId.ParameterName = "@CategoryId";
                prmCategoryId.SourceColumn = "CategoryId";
                // Add the parameters to the delete command created
                cmdDeleteCategory.Parameters.Add(prmCategoryId);
                // Assign the Delete Command to the DeleteCommand of the DataAdapter
                daQuickKart.DeleteCommand = cmdDeleteCategory;


                // Make the necessary changes to the database
                daQuickKart.Update(dtCategories);
                dtCategories = this.FetchCategorieswithDataAdapter();
            }
            catch (Exception ex)
            {
                dtCategories = null;
            }
            return dtCategories;
        }

        // 08. Working with Command Builder
        public DataTable SaveChangesUsingCommandBuilder(DataTable dtCategories)
        {
            try
            {
                SqlCommandBuilder cmd = new SqlCommandBuilder(daQuickKart);
                daQuickKart.Update(dtCategories);
                dtCategories = this.FetchCategorieswithDataAdapter();
            }
            catch (Exception ex)
            {
                dtCategories = null;
            }
            return dtCategories;
        }


    }
}
